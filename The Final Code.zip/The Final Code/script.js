document.addEventListener("DOMContentLoaded", function() {
    const chatOutput = document.getElementById("chat-output");
    const userInput = document.getElementById("user-input");
    const sendButton = document.getElementById("send-button");

    sendButton.addEventListener("click", function() {
        const userMessage = userInput.value;
        if (userMessage) {
            appendUserMessage(userMessage);
            getChatbotResponse(userMessage);
            userInput.value = "";
        }
    });

    function appendUserMessage(message) {
        const userDiv = document.createElement("div");
        userDiv.className = "user";
        userDiv.innerHTML = message;
        chatOutput.appendChild(userDiv);
    }

    function appendChatbotResponse(message) {
        const botDiv = document.createElement("div");
        botDiv.className = "chat-bot";
        botDiv.innerHTML = message;
        chatOutput.appendChild(botDiv);
    }

    function getChatbotResponse(userMessage) {
    
        const predefinedResponses = {
            "hello": "Hello! How can I assist you?",
            "how are you": "I'm fantastic and eager to help you.",
            "what's your name": "My name is EduChat.",
            "hindu gains of learning act":"Hindu Gains of Learning Act, 1930 - An Act to remove doubt as to the rights of a member of a Hindu undivided family in property acquired by him by means of his learning.",
            "dr panjabrao deshmukh hostel maintenance allowance":"Dr Panjabrao Deshmukh Hostel Maintenance Allowance:Students whose parent's annual Income is below 800000 and Student whose parent's are Marginal Land Holder and registered labour.",
            "tuition fee and exam fee for tribal students":"This is state sponsored scheme. Applicant who's parent income limit are more than 2.5 lakhs can apply of the scheme. Only applicant tuition fee and exam fee is reimbursed. Benefits - Tuition Fee and Exam Fees As per approved college fee structure",
            "rajarshi shahu maharaj merit scholarship": "Rajarshi shahu maharaj scholarship 2023 amount for sc students, Rajarshi Chhatrapati Shahu Maharaj Merit Scholarship for students studying in 11th & 12th standard of VJNT & SBC category, chhatrapati rajarshi shahu maharaj scholarship last date 2023-24",
            "pre-matric scholarship for students with disabilities":"To implement various schemes and programs to yield the social, educational and economical upliftment amongst the masses belonging to De-notified tribe, Nomadic Tribes, Other Backward Section and Special Backward Caste.",
            "ebc": "The objective of the Scheme is to provide financial assistance to the Economic Backward Class who are admitted to Diploma / Degree / Postgraduate Professional courses through Centralized Admission Process (CAP).",
            "abdul kalam technology innovation national fellowship": "Abdul Kalam Technology Innovation National Fellowship 2023-24 is a research opportunity offered by the Indian National Academy of Engineering (INAE) to outstanding engineers to recognize, encourage and support their translational research for achieving excellence in engineering, innovation, and technology development. The selected candidates will receive a monthly fellowship worth INR 25,000 and other benefits.",
            "default": "I'm just a basic chatbot. I don't have access to a real database, but I can help you with general information."
        };

        
        const response = predefinedResponses[userMessage.toLowerCase()] || predefinedResponses["default"];
        appendChatbotResponse(response);
    }
});
